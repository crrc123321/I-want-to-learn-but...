#导入图形界面库
import tkinter as tk
from tkinter import messagebox,Menu

#导入必备库
import os,threading,wxauto,requests,win32gui,sys
from wxauto import *
from threading import Thread

#设置翻译API提供商
trans='https://fanyi.baidu.com/sug'

#这是控制线程的全局标志位捏
stop=False
allon=False







#导入库
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义函数





#如果我要关闭，怎么办？
def close():
    global stop,allon
    stop=True
    allon=False
    os._exit(0)

#定义右键菜单包含功能
def cut():
    entry.event_generate("<<Cut>>")
def copy():
    entry.event_generate("<<Copy>>")
def paste():
    entry.event_generate("<<Paste>>")

#定义将输入框中的值写入到Cookie函数
def set_cookie():
    #检测是否创建文件夹
    if not os.path.exists(fway):
        os.makedirs(fway)
    else:
        pass
    
    #获取输入框中的值
    cookie = entry.get()

    #将Cookie值写入文件
    with open(fpath,'w') as file:
        file.write(cookie)    
        file.close()
        #另一个赛博异常检测
        with open(fpath,'r') as file:
            content=file.read()
            if content=="":
                tk.messagebox.showerror('你大爷','Cookie值为空翻译鸡毛，老子不干了')
            else:
                tk.messagebox.showinfo('恭喜','写入成功')
                root.destroy()

#给爷停
def stopanswering():
    global stop,allon
    stop=True
    allon=False


#古希腊掌管发送背单词的神
def thr1():
    tk.messagebox.showinfo('搞定','已开始自动解决烦人的"背单词"')
    global stop,allon
    stop=False
    allon=False
    while not stop and not allon:
        lstmsg=wx.GetAllMessage()[-1]
        if '获取新的练习题' in lstmsg[1]:
            wx.SendMsg('背单词')

#古希腊掌管验证码的神
def thr2():
    tk.messagebox.showinfo('搞定','已开始自动解决该死的验证码')
    global stop,allon
    stop=False
    allon=False
    while not stop and not allon:
        lstmsg=wx.GetAllMessage()[-1]
        if '背单词不能继续' in lstmsg[1]:
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()
            wx.SendMsg(response)

#古希腊掌管路障的神
def thr3():
    tk.messagebox.showinfo('搞定','小小路障，休想阻碍我背单词')
    global stop,allon
    stop=False
    allon=True
    while not stop and allon==True:
        lstmsg=wx.GetAllMessage()[-1]
        if '获取新的练习题' in lstmsg[1]:
            wx.SendMsg('背单词')

        elif '背单词不能继续' in lstmsg[1]:
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()
            wx.SendMsg(response)

#自动输入背单词
def enterword():
    autoinput=threading.Thread(target=thr1)
    autoinput.start()

#自动输入验证码
def enterpasscode():
    code=threading.Thread(target=thr2)
    code.start()

#自动解决路障
def enterall():
    code=threading.Thread(target=thr3)
    code.start()






#定义函数
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义窗口





#判断一下微信在在不在
handle=win32gui.FindWindow(None,'微信')
if handle==0:
    tk.messagebox.showerror('TMD','微信都不打开，怎么翻译啊')
    close()
else:
    pass

#设置Cookie存储路径
fway=r"C:\ProgramData\WhatsTheMean"
finame='Cookies.txt'
fpath=os.path.join(fway,finame)

# 创建Cookie输入窗口
root = tk.Tk()
root.title("请输入Cookie")
root.geometry("590x435+80+60")
root.resizable(width=False, height=False)
root.protocol("WM_DELETE_WINDOW",close)

#窗口上方文本参数设置
tk.Label(root, text="请到百度翻译网页获取Cookie，粘贴至下方输入框\n粘贴后点击设置Cookie\n出现”写入成功“即可进入主程序", font=("Microsoft YaHei", 10)).pack(pady=35)
tk.Label(root, text="------------------------------------------------------------", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Label(root, text="获取Token方法：打开浏览器并访问百度翻译官网，进入浏览器的开发者工具\n点击网络-Fetch/XHR\n在官网随意输入一个词后，去右侧点击translate\n复制Cookie值即可", font=("Microsoft YaHei", 10)).pack(pady=35)

# 创建一个输入框
entry = tk.Entry(root,width=64)
entry.pack(pady=0)

# 创建右键菜单
menu = Menu(root, tearoff=0)
menu.add_command(label="剪切", command=cut)
menu.add_command(label="复制", command=copy)
menu.add_command(label="粘贴", command=paste)

# 绑定右键菜单到输入框
def show_menu(event):
    menu.post(event.x_root, event.y_root)
entry.bind("<Button-3>", show_menu)

# 创建设置Cookie按钮
cookie=tk.Button(root, text="设置 Cookie", command=set_cookie).pack(pady=35)

#定义回车行为
root.bind('<Return>',lambda event:set_cookie())

# 运行主循环
root.mainloop()





#定义窗口
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#接下来做什么？





#判断一下微信“”“还”“”在不在
handle=win32gui.FindWindow(None,'微信')
if handle==0:
    tk.messagebox.showerror('TMD','你退微信干嘛啊，罢工罢工')
    close()
else:
    tk.messagebox.showinfo('注意','即将打开微信并自动寻找助手(懒得打那个唐名了，艹)，请做好准备')
    wx=WeChat()
    wx.ChatWith('英语AI学习助手')






#文件创建和Cookie写入环节
#============================================================================================
#============================================================================================
#============================================================================================
#============================================================================================
#============================================================================================
#定义函数






#定义退出程序函数
def exit_program():
    main.destroy()
    close()

#古希腊掌管启动背单词程序线程的神
def thr():
    wd=GetWord()
    hd=Headers()
    transback=GetAndSend(wd,hd)
    if type(transback) != type('test') or type(transback)==type(None):
        tk.messagebox.showinfo("检查下？",'这特么压根不是单词啊，艹\n或者检查一下Cookie是否正确？')
    else:
        tk.messagebox.showinfo("翻译结果", transback)

#开个线程罢
def startanswer():
    start=threading.Thread(target=thr)
    start.start()

#获取单词
def GetWord():
    lstmsg=wx.GetAllMessage()[-1]
    #设置起始位置
    start_index = lstmsg[1].find("【单选】") + len("【单选】")
    end_index = lstmsg[1].find("[")

    #获取字符串格式的单词本体
    gotword = lstmsg[1][start_index:end_index].strip()
    return(gotword)
    
#定义报头
def Headers():
    #使用只读权限打开Cookies.txt，设置content变量并作为报头一部分
    with open(fpath,'r') as file:
        content=file.read()
    headers={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0",
    "Cookie": content 
    }
    return(headers)

#将获取到的单词发送至翻译提供商，并取得翻译结果
def GetAndSend(gottenword,Headers):
    try:
        response=requests.post(trans,headers=Headers,data={'kw':gottenword})
        response.raise_for_status()
        data=response.json().get('data')
        return data[0]['v'] if data else None
    except Exception as e:
        return None




#定义函数
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#程序行为





#创建主窗口
main = tk.Tk()
main.title("一站式解决所有垃圾，手背党福音")
main.geometry("440x540+90+40")
main.resizable(width=False, height=False)

#窗口上方文本参数设置
tk.Label(main, text="垃圾垃圾退退退，老子直接办了你", font=("Microsoft YaHei", 14),fg='red').pack(pady=24)

#创建查询按钮
tk.Label(main, text="========查一下单词啥意思========", font=("Microsoft YaHei", 10)).pack(pady=0)
tk.Button(main, text="这词是什么意思？", fg='dark blue', bg='yellow',command=startanswer).pack(pady=20)

# 创建干掉验证按钮
tk.Label(main, text="========解决掉助手拉的史========", font=("Microsoft YaHei", 10)).pack(pady=10)
tk.Button(main,text="自动输入背单词", command=enterword).pack(pady=10)
tk.Button(main,text="自动输入该死的验证码", command=enterpasscode).pack(pady=10)
tk.Button(main,text="自动输入该死的验证码及背单词", command=enterall).pack(pady=10)
tk.Button(main,text="停，不背了", command=stopanswering).pack(pady=10)

#创建退出程序按钮
tk.Label(main, text="========我走了，不想用了========", font=("Microsoft YaHei", 10)).pack(pady=20)
tk.Button(main, text="再见", command=exit_program,bg='light green').pack(pady=0)

#运行主循环
main.mainloop()