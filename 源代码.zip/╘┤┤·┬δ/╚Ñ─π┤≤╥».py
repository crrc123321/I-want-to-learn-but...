#导入图形界面库
import tkinter as tk
from tkinter import messagebox

#导入必备库
import threading,os,win32gui,sys
from threading import Thread
from wxauto import *





#导入库
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义函数





#先给个提示+同时检测微信是否打开，如果已打开，跳转学习助手，如果没打开，直接罢工
handle=win32gui.FindWindow(None,'微信')
if handle==0:
    tk.messagebox.showerror('你大爷','微信都不打开，背个啥啊\n快去打开微信再来找我')
    sys.exit(0)
else:
    tk.messagebox.showinfo('提示','即将跳转英语AI学习助手，请做好准备')
    wx=WeChat()
    wx.ChatWith('英语AI学习助手')

#这是控制线程的全局标志位捏
stop=False
allon=False





#定义变量
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#定义函数





#给爷停
def stopanswering():
    global stop,allon
    stop=True
    allon=False

#如果我要关闭，怎么办？
def close():
    global stop,allon
    stop=True
    allon=False
    os._exit(0)

#古希腊掌管发送背单词的神
def thr1():
    tk.messagebox.showinfo('搞定','已开始自动解决烦人的"背单词"')
    global stop,allon
    stop=False
    allon=False
    while not stop and not allon:
        lstmsg=wx.GetAllMessage()[-1]
        if '获取新的练习题' in lstmsg[1]:
            wx.SendMsg('背单词')

#古希腊掌管验证码的神
def thr2():
    tk.messagebox.showinfo('搞定','已开始自动解决该死的验证码')
    global stop,allon
    stop=False
    allon=False
    while not stop and not allon:
        lstmsg=wx.GetAllMessage()[-1]
        if '背单词不能继续' in lstmsg[1]:
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()
            wx.SendMsg(response)

#古希腊掌管路障的神
def thr3():
    tk.messagebox.showinfo('搞定','小小路障，休想阻碍我背单词')
    global stop,allon
    stop=False
    allon=True
    while not stop and allon==True:
        lstmsg=wx.GetAllMessage()[-1]
        if '获取新的练习题' in lstmsg[1]:
            wx.SendMsg('背单词')

        elif '背单词不能继续' in lstmsg[1]:
            start_index = lstmsg[1].find("请回复") + len("请回复")
            end_index=lstmsg[1].find("验证单词学习行为")
            response=lstmsg[1][start_index:end_index].strip()
            wx.SendMsg(response)

#自动输入背单词
def enterword():
    autoinput=threading.Thread(target=thr1)
    autoinput.start()

#自动输入验证码
def enterpasscode():
    code=threading.Thread(target=thr2)
    code.start()

#自动解决路障
def enterall():
    code=threading.Thread(target=thr3)
    code.start()





#定义函数区
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#====================================================================
#创建窗口





# 创建窗口
root = tk.Tk()
root.iconbitmap("")
root.title("垃圾验证，耽误老子背单词")
root.geometry("320x300+80+60")
root.resizable(width=False, height=False)
root.protocol("WM_DELETE_WINDOW",close)


#窗口上方文本参数设置
tk.Label(root, text="去你大爷的背单词验证", font=("Microsoft YaHei", 20),fg="red").pack(pady=20)

# 创建按钮
tk.Button(root,text="自动输入背单词", command=enterword).pack(pady=10)
tk.Button(root,text="自动输入该死的验证码", command=enterpasscode).pack(pady=10)
tk.Button(root,text="自动输入该死的验证码及背单词", command=enterall).pack(pady=10)
tk.Button(root,text="停，不背了", command=stopanswering).pack(pady=10)

# 运行主循环
root.mainloop()